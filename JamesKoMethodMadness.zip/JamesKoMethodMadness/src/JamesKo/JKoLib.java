package JamesKo;

public class JKoLib {
    public static boolean reverse(String str) {
        String output = "";
        int i = str.length() - 1;
        while (i >= 0) {
            output = output + str.substring(i, i + 1);
            i--;
        }
        if (output.equals(str)) {
            return true;
        } else {
            return false;
        }
    }
}