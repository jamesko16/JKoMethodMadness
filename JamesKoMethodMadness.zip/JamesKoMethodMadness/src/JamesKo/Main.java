package JamesKo;

public class Main {

    public static void main(String[] args) {
        // write your code here
        System.out.println("reverse of \'rip\' is "+JKoLib.reverse( "rip"));
    }
}
